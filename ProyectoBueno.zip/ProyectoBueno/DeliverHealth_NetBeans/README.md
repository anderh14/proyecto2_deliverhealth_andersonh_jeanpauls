# Deliver Health — Proyecto NetBeans (JDK 7+ / NetBeans 7.3 / 8.x)

**Asignatura:** Programación Orientada a Objetos (UCAB)  
**Compatibilidad:** NetBeans 7.3 (2013), NetBeans 8.0/8.2 y Apache NetBeans recientes (Nivel de código fuente Java 1.7 / JDK 7+).

---

## 1. Cómo abrir y ejecutar en NetBeans

1. Descomprimir la carpeta **`DeliverHealth_NetBeans`**.
2. Abrir NetBeans -> menú **File -> Open Project...** (`Ctrl+Mayús+O`).
3. Seleccionar la carpeta **`DeliverHealth_NetBeans`** (aparecerá con el ícono de taza de café de proyecto Java) y hacer clic en **Open Project**.
4. Presionar **F6** (o clic derecho sobre el proyecto -> **Run**) para ejecutar la clase principal `com.deliverhealth.vista.Main`.

---

## 2. Credenciales Precargadas (Modo Cliente)

* **Paciente Demo:** Cédula `V-28456123` | Contraseña `1234` (Línea Cashea inicial: `$150.00`)
* **Médico Demo (Cardiología):** Cédula `V-12345678` | Contraseña `med123`
* **Médico Demo (Medicina Interna):** Cédula `V-14987654` | Contraseña `med123`

---

## 3. Suposiciones Realizadas

1. **Financiamiento Cashea:** Inicial del **40%** al confirmar la consulta y **60%** financiado en **3 cuotas sin interés**. Línea base de paciente nuevo: **$150.00 USD**.
2. **Modalidad Domicilio:** Recargo operativo del **15%** sobre la tarifa base del especialista.
3. **Disponibilidad por Especialidad:** Dermatología opera solo bajo `TELEMEDICINA`; intentar agendar a domicilio con ese especialista muestra una alerta controlada.
4. **Persistencia Local:** Serialización nativa de Java en `data/deliverhealth_db.dat` sin requerir bases de datos externas.
5. **Reembolso e Incentivo Cashea:** Cancelar una consulta financiada devuelve el saldo financiado a la línea del paciente; completar una consulta financiada otorga `+$25.00 USD` en la línea de crédito.
