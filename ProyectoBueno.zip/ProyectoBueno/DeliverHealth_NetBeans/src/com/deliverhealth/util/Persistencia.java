package com.deliverhealth.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

public class Persistencia {
    private static final String RUTA_DATOS = "data/deliverhealth_db.dat";

    public static void guardarEstado(Object sistema) {
        File dir = new File("data");
        if (!dir.exists()) {
            dir.mkdirs();
        }
        ObjectOutputStream oos = null;
        try {
            oos = new ObjectOutputStream(new FileOutputStream(RUTA_DATOS));
            oos.writeObject(sistema);
        } catch (IOException e) {
            System.err.println("[Aviso] No se pudo guardar la persistencia: " + e.getMessage());
        } finally {
            if (oos != null) {
                try { oos.close(); } catch (IOException ex) {}
            }
        }
    }

    public static Object cargarEstado() {
        File archivo = new File(RUTA_DATOS);
        if (!archivo.exists()) {
            return null;
        }
        ObjectInputStream ois = null;
        try {
            ois = new ObjectInputStream(new FileInputStream(archivo));
            return ois.readObject();
        } catch (IOException e) {
            return null;
        } catch (ClassNotFoundException e) {
            return null;
        } finally {
            if (ois != null) {
                try { ois.close(); } catch (IOException ex) {}
            }
        }
    }
}
