package com.deliverhealth.util;

import java.util.regex.Pattern;

public class Validador {
    private static final Pattern EMAIL_PATTERN = Pattern.compile("^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$");
    private static final Pattern CEDULA_PATTERN = Pattern.compile("^[VEve]-?\\d{6,9}$|^\\d{6,9}$");
    private static final Pattern TELEFONO_PATTERN = Pattern.compile("^(0412|0414|0424|0416|0426|0212)-?\\d{7}$");

    public static boolean validarCedula(String cedula) {
        return cedula != null && CEDULA_PATTERN.matcher(cedula.trim()).matches();
    }

    public static boolean validarCorreo(String correo) {
        return correo != null && EMAIL_PATTERN.matcher(correo.trim()).matches();
    }

    public static boolean validarTelefono(String telefono) {
        return telefono != null && TELEFONO_PATTERN.matcher(telefono.trim()).matches();
    }

    public static boolean validarTextoNoVacio(String texto) {
        return texto != null && !texto.trim().isEmpty();
    }
}
