package com.deliverhealth.vista;

import com.deliverhealth.modelo.Consulta;
import com.deliverhealth.modelo.Medico;
import com.deliverhealth.modelo.Paciente;
import com.deliverhealth.modelo.Usuario;
import com.deliverhealth.servicio.SistemaDeliverHealth;
import com.deliverhealth.util.Validador;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

public class Main {
    private static SistemaDeliverHealth sistema;
    private static Scanner scanner;

    public static void main(String[] args) {
        sistema = SistemaDeliverHealth.inicializar();
        scanner = new Scanner(System.in);

        boolean salir = false;
        while (!salir) {
            mostrarBanner();
            System.out.println("1. Iniciar Sesión (Paciente / Médico)");
            System.out.println("2. Registrarme como Nuevo Paciente");
            System.out.println("3. Consultar Directorio Médico y Tarifas");
            System.out.println("4. Asistente Virtual de Triaje (Chatbot)");
            System.out.println("0. Salir del Sistema");
            System.out.print("\nSeleccione una opción: ");

            String opcion = scanner.nextLine().trim();
            if ("1".equals(opcion)) {
                flujoLogin();
            } else if ("2".equals(opcion)) {
                flujoRegistroPaciente();
            } else if ("3".equals(opcion)) {
                mostrarDirectorioMedicos();
            } else if ("4".equals(opcion)) {
                flujoChatbot();
            } else if ("0".equals(opcion)) {
                salir = true;
                System.out.println("\nGracias por usar Deliver Health. ¡Cuida tu salud!");
            } else {
                System.out.println("\n[!] Opción no válida. Intente nuevamente.");
            }
        }
        scanner.close();
    }

    private static void mostrarBanner() {
        System.out.println("\n=======================================================");
        System.out.println("       DELIVER HEALTH - Salud a tu Puerta & Telemed    ");
        System.out.println("=======================================================");
    }

    private static void flujoLogin() {
        System.out.println("\n--- INICIO DE SESIÓN ---");
        System.out.println("(Usuarios demo: Paciente V-28456123 / clave: 1234 | Médico V-12345678 / clave: med123)");
        System.out.print("Cédula (ej. V-28456123): ");
        String cedula = scanner.nextLine().trim();
        System.out.print("Contraseña: ");
        String pass = scanner.nextLine().trim();

        Usuario u = sistema.autenticar(cedula, pass);
        if (u == null) {
            System.out.println("\n[!] Credenciales incorrectas o usuario no registrado.");
            return;
        }

        System.out.println("\nBienvenido(a), " + u.getNombre() + " [" + u.getRol() + "]");
        if (u instanceof Paciente) {
            menuPaciente((Paciente) u);
        } else if (u instanceof Medico) {
            menuMedico((Medico) u);
        }
    }

    private static void flujoRegistroPaciente() {
        System.out.println("\n--- REGISTRO DE NUEVO PACIENTE ---");
        String cedula;
        while (true) {
            System.out.print("Cédula (ej. V-29123456): ");
            cedula = scanner.nextLine().trim().toUpperCase();
            if (Validador.validarCedula(cedula)) break;
            System.out.println("[!] Formato de cédula inválido.");
        }

        String nombre;
        while (true) {
            System.out.print("Nombre completo: ");
            nombre = scanner.nextLine().trim();
            if (Validador.validarTextoNoVacio(nombre)) break;
            System.out.println("[!] El nombre no puede estar vacío.");
        }

        String correo;
        while (true) {
            System.out.print("Correo electrónico: ");
            correo = scanner.nextLine().trim();
            if (Validador.validarCorreo(correo)) break;
            System.out.println("[!] Formato de correo inválido.");
        }

        String telefono;
        while (true) {
            System.out.print("Teléfono móvil (ej. 0414-1234567): ");
            telefono = scanner.nextLine().trim();
            if (Validador.validarTelefono(telefono)) break;
            System.out.println("[!] Formato de teléfono venezolano inválido.");
        }

        System.out.print("Dirección de residencia (para atención a domicilio): ");
        String direccion = scanner.nextLine().trim();
        if (!Validador.validarTextoNoVacio(direccion)) direccion = "Caracas, Venezuela";

        System.out.print("Cree una contraseña: ");
        String pass = scanner.nextLine().trim();

        Paciente nuevo = new Paciente(cedula, nombre, correo, telefono, pass, direccion);
        if (sistema.registrarPaciente(nuevo)) {
            System.out.println("\n[OK] Registro exitoso. Se le ha asignado una línea inicial Cashea de $150.00.");
            menuPaciente(nuevo);
        } else {
            System.out.println("\n[!] Ya existe un usuario registrado con esa cédula.");
        }
    }

    private static void menuPaciente(Paciente paciente) {
        boolean cerrarSesion = false;
        while (!cerrarSesion) {
            System.out.println("\n--- PANEL DEL PACIENTE: " + paciente.getNombre() + " ---");
            System.out.printf("Línea Cashea Disponible: $%.2f (Nivel %d) | Dirección: %s\n",
                    paciente.getLineaCreditoCashea(), paciente.getNivelCashea(), paciente.getDireccion());
            System.out.println("1. Agendar Nueva Consulta Médica");
            System.out.println("2. Ver Mis Consultas y Estado de Pagos");
            System.out.println("3. Cancelar una Consulta Confirmada");
            System.out.println("4. Consultar Mi Historial Médico");
            System.out.println("5. Consultar Asistente Virtual (Triaje)");
            System.out.println("0. Cerrar Sesión");
            System.out.print("Seleccione una opción: ");

            String op = scanner.nextLine().trim();
            if ("1".equals(op)) {
                flujoAgendarConsulta(paciente);
            } else if ("2".equals(op)) {
                List<Consulta> misConsultas = sistema.getConsultasPorPaciente(paciente);
                System.out.println("\n--- MIS CONSULTAS ---");
                if (misConsultas.isEmpty()) {
                    System.out.println("Aún no tienes consultas agendadas.");
                } else {
                    for (Consulta c : misConsultas) {
                        System.out.println(c);
                        if (c.getPago() != null) {
                            System.out.println("   -> " + c.getPago());
                        }
                    }
                }
            } else if ("3".equals(op)) {
                flujoCancelarConsulta(paciente);
            } else if ("4".equals(op)) {
                System.out.println("\n--- HISTORIAL MÉDICO ---");
                if (paciente.getHistorialMedico().isEmpty()) {
                    System.out.println("Sin registros médicos completados aún.");
                } else {
                    for (String r : paciente.getHistorialMedico()) {
                        System.out.println(" * " + r);
                    }
                }
            } else if ("5".equals(op)) {
                flujoChatbot();
            } else if ("0".equals(op)) {
                cerrarSesion = true;
            } else {
                System.out.println("[!] Opción inválida.");
            }
        }
    }

    private static void flujoAgendarConsulta(Paciente paciente) {
        System.out.println("\n--- AGENDAR NUEVA CONSULTA ---");
        List<Medico> medicos = sistema.getMedicos();
        for (int i = 0; i < medicos.size(); i++) {
            System.out.printf("%d. %s\n", (i + 1), medicos.get(i));
        }
        System.out.print("Seleccione el número del especialista: ");
        int idx;
        try {
            idx = Integer.parseInt(scanner.nextLine().trim()) - 1;
            if (idx < 0 || idx >= medicos.size()) {
                System.out.println("[!] Selección fuera de rango.");
                return;
            }
        } catch (NumberFormatException e) {
            System.out.println("[!] Debe ingresar un número válido.");
            return;
        }

        Medico seleccionado = medicos.get(idx);
        System.out.println("\nModalidad de atención:");
        System.out.println("1. Telemedicina (Tarifa base: $" + String.format("%.2f", seleccionado.getTarifaConsulta()) + ")");
        System.out.println("2. A Domicilio (+15% logística: $" + String.format("%.2f", seleccionado.getTarifaConsulta() * 1.15) + ")");
        System.out.print("Elija modalidad (1 o 2): ");
        String modOp = scanner.nextLine().trim();
        String modalidad = "2".equals(modOp) ? "DOMICILIO" : "TELEMEDICINA";

        System.out.print("Fecha y hora deseada (formato dd/MM/yyyy HH:mm, ej. 25/11/2026 10:30): ");
        String fechaStr = scanner.nextLine().trim();
        Date fechaHora;
        SimpleDateFormat fmt = new SimpleDateFormat("dd/MM/yyyy HH:mm");
        fmt.setLenient(false);
        try {
            fechaHora = fmt.parse(fechaStr);
        } catch (ParseException e) {
            System.out.println("[!] Formato de fecha inválido. Se asignará cita para mañana a las 09:00 AM por defecto.");
            Calendar cal = Calendar.getInstance();
            cal.add(Calendar.DAY_OF_MONTH, 1);
            cal.set(Calendar.HOUR_OF_DAY, 9);
            cal.set(Calendar.MINUTE, 0);
            fechaHora = cal.getTime();
        }

        System.out.print("Motivo de la consulta / síntomas: ");
        String motivo = scanner.nextLine().trim();
        if (!Validador.validarTextoNoVacio(motivo)) motivo = "Chequeo médico general";

        System.out.println("\nMétodo de pago:");
        System.out.println("1. Pago de Contado (100%)");
        System.out.println("2. Financiamiento Cashea (40% inicial + 3 cuotas quincenales sin interés)");
        System.out.print("Seleccione método de pago (1 o 2): ");
        boolean usarCashea = "2".equals(scanner.nextLine().trim());

        try {
            Consulta confirmada = sistema.agendarConsulta(paciente, seleccionado, modalidad, fechaHora, motivo, usarCashea);
            System.out.println("\n[OK] ¡Consulta agendada y confirmada exitosamente!");
            System.out.println(confirmada);
            System.out.println(confirmada.getPago());
        } catch (Exception e) {
            System.out.println("\n[ERROR] No se pudo agendar la consulta: " + e.getMessage());
        }
    }

    private static void flujoCancelarConsulta(Paciente paciente) {
        List<Consulta> todas = sistema.getConsultasPorPaciente(paciente);
        List<Consulta> activas = new ArrayList<Consulta>();
        for (Consulta c : todas) {
            if ("CONFIRMADA".equalsIgnoreCase(c.getEstado())) {
                activas.add(c);
            }
        }

        if (activas.isEmpty()) {
            System.out.println("\nNo tienes consultas confirmadas disponibles para cancelar.");
            return;
        }

        System.out.println("\n--- CANCELAR CONSULTA ---");
        for (int i = 0; i < activas.size(); i++) {
            System.out.printf("%d. %s\n", (i + 1), activas.get(i));
        }
        System.out.print("Seleccione el número de consulta a cancelar (0 para volver): ");
        try {
            int sel = Integer.parseInt(scanner.nextLine().trim());
            if (sel > 0 && sel <= activas.size()) {
                sistema.cancelarConsulta(activas.get(sel - 1));
                System.out.println("[OK] Consulta cancelada. Si usaste Cashea, tu línea de crédito fue restaurada.");
            }
        } catch (NumberFormatException e) {
            System.out.println("[!] Entrada inválida.");
        }
    }

    private static void menuMedico(Medico medico) {
        boolean cerrarSesion = false;
        while (!cerrarSesion) {
            System.out.println("\n--- PANEL MÉDICO: Dr(a). " + medico.getNombre() + " (" + medico.getEspecialidad() + ") ---");
            System.out.println("1. Ver Mi Agenda de Pacientes");
            System.out.println("2. Atender Consulta y Registrar Diagnóstico");
            System.out.println("0. Cerrar Sesión");
            System.out.print("Seleccione una opción: ");

            String op = scanner.nextLine().trim();
            if ("1".equals(op)) {
                List<Consulta> agenda = sistema.getConsultasPorMedico(medico);
                System.out.println("\n--- AGENDA MÉDICA ---");
                if (agenda.isEmpty()) {
                    System.out.println("No tiene consultas asignadas.");
                } else {
                    for (Consulta c : agenda) {
                        System.out.println(c + " | Paciente: " + c.getPaciente().getNombre() + " | Motivo: " + c.getMotivo());
                    }
                }
            } else if ("2".equals(op)) {
                List<Consulta> todas = sistema.getConsultasPorMedico(medico);
                List<Consulta> pendientes = new ArrayList<Consulta>();
                for (Consulta c : todas) {
                    if ("CONFIRMADA".equalsIgnoreCase(c.getEstado())) {
                        pendientes.add(c);
                    }
                }
                if (pendientes.isEmpty()) {
                    System.out.println("\nNo tiene consultas confirmadas pendientes por atender.");
                } else {
                    for (int i = 0; i < pendientes.size(); i++) {
                        System.out.printf("%d. %s - Paciente: %s (Motivo: %s)\n",
                                (i + 1), pendientes.get(i).getIdConsulta(),
                                pendientes.get(i).getPaciente().getNombre(), pendientes.get(i).getMotivo());
                    }
                    System.out.print("Seleccione consulta atendida: ");
                    try {
                        int idx = Integer.parseInt(scanner.nextLine().trim()) - 1;
                        if (idx >= 0 && idx < pendientes.size()) {
                            System.out.print("Ingrese diagnóstico e indicaciones médicas: ");
                            String diag = scanner.nextLine().trim();
                            sistema.completarConsulta(pendientes.get(idx), diag);
                            System.out.println("[OK] Consulta completada e historial del paciente actualizado.");
                        }
                    } catch (NumberFormatException e) {
                        System.out.println("[!] Entrada inválida.");
                    }
                }
            } else if ("0".equals(op)) {
                cerrarSesion = true;
            } else {
                System.out.println("[!] Opción inválida.");
            }
        }
    }

    private static void mostrarDirectorioMedicos() {
        System.out.println("\n--- DIRECTORIO DE ESPECIALISTAS DELIVER HEALTH ---");
        for (Medico m : sistema.getMedicos()) {
            System.out.println(" * " + m);
        }
    }

    private static void flujoChatbot() {
        System.out.println("\n--- ASISTENTE VIRTUAL DELIVER HEALTH ---");
        System.out.print("Describe brevemente tus síntomas o qué especialista buscas: ");
        String input = scanner.nextLine().trim();
        System.out.println("\n" + sistema.evaluarSintomasChatbot(input));
    }
}
