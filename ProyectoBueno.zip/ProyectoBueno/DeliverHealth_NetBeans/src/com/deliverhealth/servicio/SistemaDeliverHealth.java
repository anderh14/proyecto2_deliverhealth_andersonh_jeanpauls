package com.deliverhealth.servicio;

import com.deliverhealth.modelo.Consulta;
import com.deliverhealth.modelo.Medico;
import com.deliverhealth.modelo.Paciente;
import com.deliverhealth.modelo.Pago;
import com.deliverhealth.modelo.Usuario;
import com.deliverhealth.util.Persistencia;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class SistemaDeliverHealth implements Serializable {
    private static final long serialVersionUID = 1L;
    private List<Paciente> pacientes;
    private List<Medico> medicos;
    private List<Consulta> consultas;
    private int contadorConsultas;
    private int contadorPagos;

    public SistemaDeliverHealth() {
        this.pacientes = new ArrayList<Paciente>();
        this.medicos = new ArrayList<Medico>();
        this.consultas = new ArrayList<Consulta>();
        this.contadorConsultas = 100;
        this.contadorPagos = 500;
        precargarDatosIniciales();
    }

    public static SistemaDeliverHealth inicializar() {
        Object cargado = Persistencia.cargarEstado();
        if (cargado instanceof SistemaDeliverHealth) {
            return (SistemaDeliverHealth) cargado;
        }
        SistemaDeliverHealth nuevo = new SistemaDeliverHealth();
        Persistencia.guardarEstado(nuevo);
        return nuevo;
    }

    private void precargarDatosIniciales() {
        pacientes.add(new Paciente("V-28456123", "Carlos Mendoza", "carlos@correo.com", "0414-1234567", "1234", "Chacao, Caracas"));
        pacientes.add(new Paciente("V-30112233", "Ana Sofía Rivas", "ana@correo.com", "0412-9876543", "1234", "Montalbán, Caracas"));

        medicos.add(new Medico("V-12345678", "Elena Valero", "evalero@deliverhealth.ve", "0414-5550101", "med123",
                "Cardiología", "MPPS-45890", 60.00, true));
        medicos.add(new Medico("V-14987654", "Roberto Salazar", "rsalazar@deliverhealth.ve", "0424-5550202", "med123",
                "Medicina Interna", "MPPS-39210", 45.00, true));
        medicos.add(new Medico("V-16777888", "Mariana Gómez", "mgomez@deliverhealth.ve", "0412-5550303", "med123",
                "Pediatría", "MPPS-51004", 50.00, true));
        medicos.add(new Medico("V-11223344", "Luis Perdomo", "lperdomo@deliverhealth.ve", "0416-5550404", "med123",
                "Dermatología", "MPPS-28741", 55.00, false));
    }

    public boolean registrarPaciente(Paciente p) {
        if (buscarUsuarioPorCedula(p.getCedula()) != null) {
            return false;
        }
        pacientes.add(p);
        Persistencia.guardarEstado(this);
        return true;
    }

    public Usuario autenticar(String cedula, String password) {
        Usuario u = buscarUsuarioPorCedula(cedula);
        if (u != null && u.getPassword().equals(password)) {
            return u;
        }
        return null;
    }

    public Usuario buscarUsuarioPorCedula(String cedula) {
        String cedNorm = cedula.trim().toUpperCase();
        for (Paciente p : pacientes) {
            if (p.getCedula().equalsIgnoreCase(cedNorm)) return p;
        }
        for (Medico m : medicos) {
            if (m.getCedula().equalsIgnoreCase(cedNorm)) return m;
        }
        return null;
    }

    public List<Medico> getMedicos() {
        return medicos;
    }

    public List<Medico> buscarMedicosPorEspecialidad(String especialidad) {
        List<Medico> resultado = new ArrayList<Medico>();
        for (Medico m : medicos) {
            if (m.getEspecialidad().toLowerCase().contains(especialidad.toLowerCase())) {
                resultado.add(m);
            }
        }
        return resultado;
    }

    public Consulta agendarConsulta(Paciente paciente, Medico medico, String modalidad,
                                    Date fechaHora, String motivo, boolean usarCashea) throws Exception {
        if (modalidad.equalsIgnoreCase("DOMICILIO") && !medico.isDisponibleDomicilio()) {
            throw new Exception("El especialista seleccionado no realiza visitas a domicilio.");
        }

        String idCons = "CONS-" + (++contadorConsultas);
        Consulta nueva = new Consulta(idCons, paciente, medico, modalidad.toUpperCase(), fechaHora, motivo);

        String idPago = "PAG-" + (++contadorPagos);
        Pago pago;

        if (usarCashea) {
            double inicial = Math.round(nueva.getMontoTotal() * 0.40 * 100.0) / 100.0;
            double montoFinanciado = Math.round((nueva.getMontoTotal() - inicial) * 100.0) / 100.0;

            if (paciente.getLineaCreditoCashea() < montoFinanciado) {
                throw new Exception(String.format(
                        "Línea de crédito Cashea insuficiente ($%.2f disponible vs $%.2f requerido a financiar).",
                        paciente.getLineaCreditoCashea(), montoFinanciado));
            }
            paciente.setLineaCreditoCashea(paciente.getLineaCreditoCashea() - montoFinanciado);
            pago = new Pago(idPago, "CASHEA", nueva.getMontoTotal(), inicial, 3);
        } else {
            pago = new Pago(idPago, "CONTADO", nueva.getMontoTotal(), nueva.getMontoTotal(), 0);
        }

        nueva.setPago(pago);
        nueva.setEstado("CONFIRMADA");
        consultas.add(nueva);
        Persistencia.guardarEstado(this);
        return nueva;
    }

    public List<Consulta> getConsultasPorPaciente(Paciente p) {
        List<Consulta> resultado = new ArrayList<Consulta>();
        for (Consulta c : consultas) {
            if (c.getPaciente().getCedula().equalsIgnoreCase(p.getCedula())) {
                resultado.add(c);
            }
        }
        return resultado;
    }

    public List<Consulta> getConsultasPorMedico(Medico m) {
        List<Consulta> resultado = new ArrayList<Consulta>();
        for (Consulta c : consultas) {
            if (c.getMedico().getCedula().equalsIgnoreCase(m.getCedula())) {
                resultado.add(c);
            }
        }
        return resultado;
    }

    public void completarConsulta(Consulta c, String diagnostico) {
        c.setDiagnostico(diagnostico);
        c.setEstado("COMPLETADA");
        c.getPaciente().agregarRegistroHistorial(
                String.format("[%s] %s - Diagnóstico: %s", c.getIdConsulta(), c.getMedico().getEspecialidad(), diagnostico)
        );
        if (c.getPago() != null && "CASHEA".equalsIgnoreCase(c.getPago().getMetodo())) {
            c.getPaciente().setLineaCreditoCashea(c.getPaciente().getLineaCreditoCashea() + 25.0);
        }
        Persistencia.guardarEstado(this);
    }

    public void cancelarConsulta(Consulta c) {
        if ("CONFIRMADA".equalsIgnoreCase(c.getEstado())) {
            c.setEstado("CANCELADA");
            if (c.getPago() != null && "CASHEA".equalsIgnoreCase(c.getPago().getMetodo())) {
                double montoFinanciado = c.getPago().getMontoTotal() - c.getPago().getInicialPagada();
                c.getPaciente().setLineaCreditoCashea(c.getPaciente().getLineaCreditoCashea() + montoFinanciado);
            }
            Persistencia.guardarEstado(this);
        }
    }

    public String evaluarSintomasChatbot(String sintomas) {
        String s = sintomas.toLowerCase();
        if (s.contains("pecho") || s.contains("corazón") || s.contains("palpitaciones") || s.contains("presión") || s.contains("tension")) {
            return "Asistente Deliver Health: Tus síntomas sugieren una valoración cardiovascular. Te recomendamos agendar con Cardiología (Dra. Elena Valero). Si hay dolor intenso, acude a emergencias.";
        } else if (s.contains("piel") || s.contains("mancha") || s.contains("erupción") || s.contains("acné") || s.contains("alergia")) {
            return "Asistente Deliver Health: Para afecciones cutáneas o alergias en piel, la especialidad indicada es Dermatología (Dr. Luis Perdomo - modalidad Telemedicina).";
        } else if (s.contains("niño") || s.contains("bebé") || s.contains("hijo") || s.contains("pediatra")) {
            return "Asistente Deliver Health: Para atención infantil, te recomendamos agendar con Pediatría (Dra. Mariana Gómez).";
        } else {
            return "Asistente Deliver Health: Para una evaluación clínica integral (fiebre, malestar general, control), te recomendamos Medicina Interna (Dr. Roberto Salazar), disponible a domicilio o telemedicina.";
        }
    }
}
