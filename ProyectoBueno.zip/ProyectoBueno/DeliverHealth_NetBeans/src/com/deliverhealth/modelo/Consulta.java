package com.deliverhealth.modelo;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Consulta implements Serializable {
    private static final long serialVersionUID = 1L;
    private String idConsulta;
    private Paciente paciente;
    private Medico medico;
    private String modalidad;
    private Date fechaHora;
    private String motivo;
    private String estado;
    private String diagnostico;
    private double montoTotal;
    private Pago pago;

    public Consulta(String idConsulta, Paciente paciente, Medico medico, String modalidad,
                    Date fechaHora, String motivo) {
        this.idConsulta = idConsulta;
        this.paciente = paciente;
        this.medico = medico;
        this.modalidad = modalidad;
        this.fechaHora = fechaHora;
        this.motivo = motivo;
        this.estado = "PENDIENTE";
        this.diagnostico = "Sin diagnóstico registrado";
        this.montoTotal = modalidad.equalsIgnoreCase("DOMICILIO")
                ? medico.getTarifaConsulta() * 1.15
                : medico.getTarifaConsulta();
    }

    public String getIdConsulta() { return idConsulta; }
    public Paciente getPaciente() { return paciente; }
    public Medico getMedico() { return medico; }
    public String getModalidad() { return modalidad; }
    public Date getFechaHora() { return fechaHora; }
    public String getMotivo() { return motivo; }
    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }
    public String getDiagnostico() { return diagnostico; }
    public void setDiagnostico(String diagnostico) { this.diagnostico = diagnostico; }
    public double getMontoTotal() { return montoTotal; }
    public Pago getPago() { return pago; }
    public void setPago(Pago pago) { this.pago = pago; }

    @Override
    public String toString() {
        SimpleDateFormat fmt = new SimpleDateFormat("dd/MM/yyyy HH:mm");
        return String.format("ID: %s | Fecha: %s | Médico: Dr(a). %s (%s) | Modalidad: %s | Total: $%.2f | Estado: %s",
                idConsulta, fmt.format(fechaHora), medico.getNombre(), medico.getEspecialidad(),
                modalidad, montoTotal, estado);
    }
}
