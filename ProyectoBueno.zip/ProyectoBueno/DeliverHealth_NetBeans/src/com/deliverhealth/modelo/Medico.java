package com.deliverhealth.modelo;

public class Medico extends Usuario {
    private static final long serialVersionUID = 1L;
    private String especialidad;
    private String numeroColegiado;
    private double tarifaConsulta;
    private boolean disponibleDomicilio;

    public Medico(String cedula, String nombre, String correo, String telefono, String password,
                  String especialidad, String numeroColegiado, double tarifaConsulta, boolean disponibleDomicilio) {
        super(cedula, nombre, correo, telefono, password);
        this.especialidad = especialidad;
        this.numeroColegiado = numeroColegiado;
        this.tarifaConsulta = tarifaConsulta;
        this.disponibleDomicilio = disponibleDomicilio;
    }

    @Override
    public String getRol() {
        return "MEDICO";
    }

    public String getEspecialidad() { return especialidad; }
    public void setEspecialidad(String especialidad) { this.especialidad = especialidad; }

    public String getNumeroColegiado() { return numeroColegiado; }
    public void setNumeroColegiado(String numeroColegiado) { this.numeroColegiado = numeroColegiado; }

    public double getTarifaConsulta() { return tarifaConsulta; }
    public void setTarifaConsulta(double tarifaConsulta) { this.tarifaConsulta = tarifaConsulta; }

    public boolean isDisponibleDomicilio() { return disponibleDomicilio; }
    public void setDisponibleDomicilio(boolean disponibleDomicilio) { this.disponibleDomicilio = disponibleDomicilio; }

    @Override
    public String toString() {
        return String.format("Dr(a). %s | Especialidad: %s | Tarifa: $%.2f | Domicilio: %s",
                getNombre(), especialidad, tarifaConsulta, disponibleDomicilio ? "Sí" : "No");
    }
}
