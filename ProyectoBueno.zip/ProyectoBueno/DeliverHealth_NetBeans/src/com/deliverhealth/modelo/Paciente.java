package com.deliverhealth.modelo;

import java.util.ArrayList;
import java.util.List;

public class Paciente extends Usuario {
    private static final long serialVersionUID = 1L;
    private String direccion;
    private int nivelCashea;
    private double lineaCreditoCashea;
    private List<String> historialMedico;

    public Paciente(String cedula, String nombre, String correo, String telefono, String password, String direccion) {
        super(cedula, nombre, correo, telefono, password);
        this.direccion = direccion;
        this.nivelCashea = 1;
        this.lineaCreditoCashea = 150.00;
        this.historialMedico = new ArrayList<String>();
    }

    @Override
    public String getRol() {
        return "PACIENTE";
    }

    public void agregarRegistroHistorial(String registro) {
        historialMedico.add(registro);
    }

    public String getDireccion() { return direccion; }
    public void setDireccion(String direccion) { this.direccion = direccion; }

    public int getNivelCashea() { return nivelCashea; }
    public void setNivelCashea(int nivelCashea) { this.nivelCashea = nivelCashea; }

    public double getLineaCreditoCashea() { return lineaCreditoCashea; }
    public void setLineaCreditoCashea(double lineaCreditoCashea) { this.lineaCreditoCashea = lineaCreditoCashea; }

    public List<String> getHistorialMedico() { return historialMedico; }
}
