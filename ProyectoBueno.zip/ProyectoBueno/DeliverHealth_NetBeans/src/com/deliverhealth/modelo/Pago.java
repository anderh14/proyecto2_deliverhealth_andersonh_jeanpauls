package com.deliverhealth.modelo;

import java.io.Serializable;
import java.util.Date;

public class Pago implements Serializable {
    private static final long serialVersionUID = 1L;
    private String idPago;
    private String metodo;
    private double montoTotal;
    private double inicialPagada;
    private int numeroCuotas;
    private double montoPorCuota;
    private Date fechaRegistro;
    private String estadoPago;

    public Pago(String idPago, String metodo, double montoTotal, double inicialPagada, int numeroCuotas) {
        this.idPago = idPago;
        this.metodo = metodo;
        this.montoTotal = montoTotal;
        this.inicialPagada = inicialPagada;
        this.numeroCuotas = numeroCuotas;
        this.montoPorCuota = (numeroCuotas > 0) ? (montoTotal - inicialPagada) / numeroCuotas : 0.0;
        this.fechaRegistro = new Date();
        this.estadoPago = (numeroCuotas == 0) ? "PAGADO_TOTAL" : "FINANCIADO_ACTIVO";
    }

    public String getIdPago() { return idPago; }
    public String getMetodo() { return metodo; }
    public double getMontoTotal() { return montoTotal; }
    public double getInicialPagada() { return inicialPagada; }
    public int getNumeroCuotas() { return numeroCuotas; }
    public double getMontoPorCuota() { return montoPorCuota; }
    public String getEstadoPago() { return estadoPago; }

    @Override
    public String toString() {
        if ("CASHEA".equalsIgnoreCase(metodo)) {
            return String.format("Pago %s [CASHEA] - Total: $%.2f | Inicial pagada (40%%): $%.2f | %d cuotas sin interés de $%.2f c/u (%s)",
                    idPago, montoTotal, inicialPagada, numeroCuotas, montoPorCuota, estadoPago);
        }
        return String.format("Pago %s [CONTADO] - Total pagado: $%.2f (%s)", idPago, montoTotal, estadoPago);
    }
}
